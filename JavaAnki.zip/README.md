# JavaAnki

![Icon](icon.ico)

**JavaAnki** — это десктопное приложение для интервального повторения (SRS), написанное на чистой Java (Swing).
Проект построен на принципах **Layered Architecture** и **MVC**, что обеспечивает модульность, тестируемость и стабильность данных.

Приложение распространяется в виде **portable .exe** (со встроенной JRE), что не требует от конечного пользователя установки Java.

##  Ключевые особенности

*   **Архитектура MVC & Passive View:** Четкое разделение логики (Controller), отображения (View) и данных (Model).
*   **Session Management:** Централизованный менеджер сессии (`SessionManager`), управляющий жизненным циклом данных, дедупликацией и миграцией.
*   **Умный алгоритм (SRS):**
    *   Система уровней (Box 0-10).
    *   "Мягкий сброс" прогресса при ошибках на высоких уровнях.
    *   Взвешенный случайный выбор (Weighted Random) карт.
*   **Data Integrity (UUID):** Каждая карточка имеет уникальный ID, что позволяет редактировать текст вопроса без потери прогресса обучения.
*   **Fuzzy Matching:** Проверка ответов с толерантностью к опечаткам (алгоритм Левенштейна + токенизация).
*   **Event-Driven UI:** Компоненты общаются через шину событий (`EventBus`), обновляясь автоматически при изменении данных.
*   **Deep Theming:** Темная/Светлая тема с рекурсивной перекраской всех компонентов, включая ScrollBars и ComboBoxes.

---

##  Технологический стек

*   **Язык:** Java 17+
*   **UI:** Swing (Custom Look & Feel, No 3rd party libs).
*   **Build Tool:** `jpackage` (Native Image/Bundle).
*   **Patterns:** Repository, Facade, MVC, Observer, Factory Method, Singleton.
*   **Testing:** JUnit 5 (Unit Tests) + Custom Integration Runners.
*   **Tools:** Lombok, Java Util Logging.

---

##  Сборка в EXE

Проект собирается в самодостаточный пакет с помощью `jpackage`.

### Инструкция по сборке

1.  **Сборка JAR:**
    В IDE выполните: `Build` -> `Build Artifacts` -> `Build`.
    Полученный файл: `out/artifacts/JavaAnki_jar/JavaAnki.jar`.

2.  **Подготовка:**
    Создайте папку сборки и поместите туда:
    *   `JavaAnki.jar`
    *   `icon.ico`
    *   Папку `decks` и файл `import.txt`.

3.  **Генерация EXE:**
    Запустите команду в терминале (PowerShell):

```powershell
jpackage `
  --name JavaAnki `
  --input . `
  --main-jar JavaAnki.jar `
  --main-class app.App `
  --type app-image `
  --icon icon.ico `
  --win-console
```
*(Удалите `--win-console`, если хотите скрыть консольное окно при запуске)*.

4.  **Финализация:**
    Скопируйте папку `decks` и `import.txt` внутрь созданной папки `JavaAnki` (рядом с .exe файлом).

---

##  Запуск (для разработчиков)

### Требования
1.  **JDK 17** или выше.
2.  **Lombok** (подключен в IDE или classpath).

### Запуск из IDE
1.  Откройте проект в IntelliJ IDEA.
2.  Убедитесь, что включена обработка аннотаций (Annotation Processing).
3.  Запустите класс `app.App`.

### Запуск тестов
*   **Unit-тесты (JUnit 5):** Запускайте папку `src` через встроенный раннер IDE.
*   **Ручные интеграционные тесты:** Запустите класс `TestRunner` (проверяет парсеры, алгоритмы и UI-контроллеры без поднятия тяжелого GUI).

---

##  Руководство пользователя

### 1. Импорт вопросов
Создайте файл `import.txt` в папке с программой. Формат (разделитель `===`):

```text
CATEGORY: Java Basics
QUESTION:
Что такое JVM?
ANSWER:
Java Virtual Machine - виртуальная машина, исполняющая байт-код.
===
```

1.  Перейдите на вкладку **"Статистика"**.
2.  Нажмите **"Импорт из файла"**.
3.  Система обработает файл:
    *   Успешные карты добавятся в файлы `decks/CategoryName.txt`.
    *   Успешные блоки удалятся из `import.txt`.
    *   Ошибки останутся в `import.txt` для исправления.

### 2. Организация групп
Файл `decks/structure.txt` позволяет объединять разрозненные файлы в темы:
```text
GROUP: Backend
FILES: java.txt, sql.txt
```

### 3. Горячие клавиши (Обучение)
*   `ENTER` — Проверить ответ.
*   `→` (Вправо) — Знаю (Уровень +1).
*   `←` (Влево) — Забыл (Сброс уровня).

---

##  Файловая структура (Portable версия)

Пользователь получает папку со следующей структурой:

*   `JavaAnki.exe` — Исполняемый файл.
*   `decks/` — Папка с вопросами (.txt).
*   `anki_stats.txt` — Файл прогресса (создается автоматически).
*   `history_log.txt` — Лог ответов (создается автоматически).
*   `import.txt` — Файл для добавления вопросов.
*   `app/`, `runtime/` — Системные файлы Java (внутри сборки).

---

##  Структура исходного кода

```text
src/
├── app/                 # Точка входа (Composition Root)
├── config/              # Цветовая палитра
├── data/                # Data Access Layer (Files, Repositories)
├── model/               # Сущности (Card, HistoryRecord)
├── service/             # Business Logic Layer (SRS, Session, Grading)
├── ui/                  # Presentation Layer (Swing, MVC Controllers)
└── util/                # Утилиты (EventBus, Parsers)
```

---

##  Решение проблем

**Ошибка при запуске .exe:**
> "Не удалось запустить приложение, поскольку его параллельная конфигурация неправильна"

Это означает, что в системе отсутствуют библиотеки Visual C++, необходимые для Java-лаунчера.
Решение: Скачать и установить [Visual C++ Redistributable x64](https://aka.ms/vs/17/release/vc_redist.x64.exe).